
public class Main {

	public static void main(String[] args) {
		
		for(int i=0;i<2;i++)
		{
		    HouseTemplate houseType;
		    if(i==0)
		    {
		        houseType = new WoodenHouse();
		        houseType.buildHouse();
		        System.out.println("******LETS BUILD A NEW HOUSE******");
		    }
		    else
		    {
		        houseType = new GlassHouse();
		        houseType.buildHouse();
		    }
		}
	}

}